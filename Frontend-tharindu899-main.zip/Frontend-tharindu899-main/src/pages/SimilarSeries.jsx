// src/pages/SimilarSeries.jsx
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import MediaSection from "../components/MediaSection";
import ShadPagination from "@/components/Pagination";

export default function SimilarSeries() {
  const BASE = import.meta.env.VITE_BASE_URL;
  const { seriesID, dbIndex } = useParams();
  

  const [series, setSeries] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [title, setTitle] = useState("");

  const fetchSimilarSeries = async () => {
    setIsLoading(true);
    try {
      const { data } = await axios.get(`${BASE}/api/similar/`, {
        params: {
          tmdb_id: seriesID,
          media_type: "tvshow",
          page_size: 24,
          page: currentPage,
        },
      });
      setSeries(data.similar_media);
      setTotalCount(data.total_count);
    } catch (error) {
      console.error("Error fetching similar series:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchSeriesTitle = async () => {
    try {
      const { data } = await axios.get(`${BASE}/api/id/${seriesID}/${dbIndex}`);
      setTitle(data.title);
    } catch (error) {
      console.error("Error fetching series title:", error);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchSimilarSeries();
    fetchSeriesTitle();
  }, [currentPage, seriesID]);

  return (
    <div className="space-y-10">
      <MediaSection
        movieData={series}
        isMovieDataLoading={isLoading}
        dataType="similarSeries"
        sectionTitle={`Similar to: ${title}`}
      />

      <ShadPagination
        currentPage={currentPage}
        totalCount={totalCount}
        pageSize={24}
        onPageChange={setCurrentPage}
      />
    </div>
  );
}

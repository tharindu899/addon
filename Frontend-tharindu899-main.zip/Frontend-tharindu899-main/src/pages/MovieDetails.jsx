// src/pages/MovieDetails.jsx
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import DetailsSections from "../components/DetailsSections";
import Similars from "../components/Similars";

export default function MovieDetails() {
  const BASE = import.meta.env.VITE_BASE_URL;
  // const { movieID } = useParams();
  const { movieID, dbIndex } = useParams();

  const [movieDetail, setMovieDetail] = useState({});
  const [similarMovies, setSimilarMovies] = useState([]);
  const [isDetailsLoading, setIsDetailsLoading] = useState(true);
  const [isSimilarLoading, setIsSimilarLoading] = useState(true);

  // Fetch movie details
  const fetchMovieDetails = async () => {
    try {
      setIsDetailsLoading(true);
      const { data } = await axios.get(`${BASE}/api/id/${movieID}/${dbIndex}`);
      setMovieDetail(data);
    } catch (error) {
      console.error("Error fetching movie details:", error);
    } finally {
      setIsDetailsLoading(false);
    }
  };

  // Fetch similar movies
  const fetchSimilarMovies = async () => {
    try {
      setIsSimilarLoading(true);
      const { data } = await axios.get(`${BASE}/api/similar/`, {
        params: {
          tmdb_id: movieID,
          media_type: "movie",
          page_size: 12,
        },
      });
      setSimilarMovies(data.similar_media);
    } catch (error) {
      console.error("Error fetching similar movies:", error);
    } finally {
      setIsSimilarLoading(false);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchMovieDetails();
    fetchSimilarMovies();
  }, [movieID]);

  return (
    <div>
      <DetailsSections
        movieData={movieDetail}
        isMovieDataLoading={isDetailsLoading}
        detailType="movie"
      />

      <Similars
        movieData={similarMovies}
        isMovieDataLoading={isSimilarLoading}
        sectionTitle="You may also like"
        detailType="similarMovies"
        seeMoreButtonLink={`/SimilarMovie/${movieID}/${dbIndex}`}
      />
    </div>
  );
}

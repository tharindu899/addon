// src/pages/Home.jsx
import React, { useEffect, useReducer } from "react";
import axios from "axios";
import Hero from "../components/Hero";
import HomeSections from "../components/HomeSections";

// Initial state for the reducer
const initialState = {
  heroPopularMovies: [],
  trendingMovies: [],
  trendingTv: [],
  isHeroLoading: true,
  isTrendingMoviesLoading: true,
  isTrendingTvLoading: true,
};

// Reducer to handle all loading and data state
function reducer(state, action) {
  switch (action.type) {
    case "SET_HERO":
      return { ...state, heroPopularMovies: action.payload, isHeroLoading: false };
    case "SET_TRENDING_MOVIES":
      return { ...state, trendingMovies: action.payload, isTrendingMoviesLoading: false };
    case "SET_TRENDING_TV":
      return { ...state, trendingTv: action.payload, isTrendingTvLoading: false };
    case "LOADING_HERO":
      return { ...state, isHeroLoading: true };
    case "LOADING_MOVIES":
      return { ...state, isTrendingMoviesLoading: true };
    case "LOADING_TV":
      return { ...state, isTrendingTvLoading: true };
    default:
      return state;
  }
}

export default function Home() {
  const BASE = import.meta.env.VITE_BASE_URL;
  const [state, dispatch] = useReducer(reducer, initialState);

  const fetchData = async (endpoint, params, type, loadingType) => {
    dispatch({ type: loadingType });
    try {
      const response = await axios.get(`${BASE}${endpoint}`, { params });
      dispatch({ type, payload: response.data.movies || response.data.tv_shows || [] });
    } catch (error) {
      console.error(`Error fetching ${type.toLowerCase()}:`, error);
      dispatch({ type }); // Still reset loading
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);

    fetchData(
      "/api/movies",
      { sort_by: "release_year:desc", page: 1, page_size: 10 },
      "SET_HERO",
      "LOADING_HERO"
    );

    fetchData(
      "/api/movies",
      { sort_by: "updated_on:desc", page: 1, page_size: 24 },
      "SET_TRENDING_MOVIES",
      "LOADING_MOVIES"
    );

    fetchData(
      "/api/tvshows",
      { sort_by: "updated_on:desc", page: 1, page_size: 24 },
      "SET_TRENDING_TV",
      "LOADING_TV"
    );
  }, [BASE]);

  return (
    <div>
      {/* HEADER - Hero and boxoffice */}
      <div className="col-span-1 lg:col-span-2">
        <Hero
          movieData={state.heroPopularMovies}
          isMovieDataLoading={state.isHeroLoading}
          dataType="heroPopularMovies"
          sliderTypePrev="slideHeroTrendingMovies-prev"
          sliderTypeNext="slideHeroTrendingMovies-next"
        />
      </div>

      {/* Trending Movies Section */}
      <HomeSections
        movieData={state.trendingMovies}
        isMovieDataLoading={state.isTrendingMoviesLoading}
        sectionTitle="Latest Movies"
        sectionSeeMoreButtonLink="/Movies"
        dataType="latestMovies"
      />

      {/* Trending TV SHOWS Section */}
      <HomeSections
        movieData={state.trendingTv}
        isMovieDataLoading={state.isTrendingTvLoading}
        sectionTitle="Latest Series"
        sectionSeeMoreButtonLink="/Series"
        dataType="latestTv"
      />
    </div>
  );
}

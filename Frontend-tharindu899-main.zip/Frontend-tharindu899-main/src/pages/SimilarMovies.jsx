// src/pages/SimilarMovies.jsx
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import MediaSection from "../components/MediaSection";
import ShadPagination from "@/components/Pagination";

export default function SimilarMovies() {
  const BASE = import.meta.env.VITE_BASE_URL;
  const { movieID, dbIndex } = useParams();
  
  

  const [movies, setMovies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [title, setTitle] = useState("");

  const fetchSimilarMovies = async () => {
    setIsLoading(true);
    try {
      const { data } = await axios.get(`${BASE}/api/similar/`, {
        params: {
          tmdb_id: movieID,
          media_type: "movie",
          page_size: 24,
          page: currentPage,
        },
      });

      console.log("Similar Movies Fetched:", data.similar_media.length);
      setMovies(data.similar_media);
      setTotalCount(data.total_count);
    } catch (error) {
      console.error("Error fetching similar movies:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchMovieTitle = async () => {
    try {
      const { data } = await axios.get(`${BASE}/api/id/${movieID}/${dbIndex}`);
      setTitle(data.title);
    } catch (error) {
      console.error("Error fetching movie title:", error);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchSimilarMovies();
    fetchMovieTitle();
  }, [currentPage, movieID]);

  return (
    <div className="space-y-10">
      <MediaSection
        movieData={movies}
        isMovieDataLoading={isLoading}
        dataType="similarMovies"
        sectionTitle={`Similar to: ${title}`}
      />

      <ShadPagination
        currentPage={currentPage}
        totalCount={totalCount}
        pageSize={24}
        onPageChange={setCurrentPage}
      />
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import DetailsSections from "../components/DetailsSections";
import Similars from "../components/Similars";

export default function SeriesDetails() {
  const BASE = import.meta.env.VITE_BASE_URL;
  const { seriesID, dbIndex } = useParams();

  const [seriesDetail, setSeriesDetail] = useState({});
  const [similarSeries, setSimilarSeries] = useState([]);
  const [episodes, setEpisodes] = useState([]);
  const [seasonNumber, setSeasonNumber] = useState(1);
  const [episodeNumber, setEpisodeNumber] = useState();
  const [isLoading, setIsLoading] = useState({
    details: true,
    similar: true,
    episodes: true,
  });

  // Fetch series details and sort seasons
  const fetchSeriesDetails = async () => {
    try {
      setIsLoading((prev) => ({ ...prev, details: true }));
      const { data } = await axios.get(`${BASE}/api/id/${seriesID}/${dbIndex}`);
      const sortedSeasons = data.seasons?.sort(
        (a, b) => a.season_number - b.season_number
      ) || [];
      setSeriesDetail({ ...data, seasons: sortedSeasons });

      if (sortedSeasons.length > 0) {
        setSeasonNumber(sortedSeasons[0].season_number);
      }
    } catch (error) {
      console.error("Error fetching series details:", error);
    } finally {
      setIsLoading((prev) => ({ ...prev, details: false }));
    }
  };

  // Fetch similar series
  const fetchSimilarSeries = async () => {
    try {
      setIsLoading((prev) => ({ ...prev, similar: true }));
      const { data } = await axios.get(`${BASE}/api/similar/`, {
        params: {
          tmdb_id: seriesID,
          media_type: "tvshow",
          page_size: 12,
        },
      });
      setSimilarSeries(data.similar_media);
    } catch (error) {
      console.error("Error fetching similar series:", error);
    } finally {
      setIsLoading((prev) => ({ ...prev, similar: false }));
    }
  };

  // Fetch episodes for selected season
  const fetchEpisodes = async () => {
    if (!seasonNumber) return;

    try {
      setIsLoading((prev) => ({ ...prev, episodes: true }));
      const { data } = await axios.get(`${BASE}/api/id/${seriesID}/${dbIndex}`, {
        params: { season_number: seasonNumber },
      });
      setEpisodes(data.episodes);
    } catch (error) {
      console.error("Error fetching episodes:", error);
    } finally {
      setIsLoading((prev) => ({ ...prev, episodes: false }));
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchSeriesDetails();
    fetchSimilarSeries();
  }, [seriesID]);

  useEffect(() => {
    fetchEpisodes();
  }, [seasonNumber, seriesID]);

  return (
    <div>
      <DetailsSections
        movieData={seriesDetail}
        isMovieDataLoading={isLoading.details}
        detailType="series"
        seasonNumber={seasonNumber}
        episodeNumber={episodeNumber}
        setEpisodeNumber={setEpisodeNumber}
        setSeasonNumber={setSeasonNumber}
        isEpisodesLoading={isLoading.episodes}
        episodes={episodes}
        setEpisodes={setEpisodes}
      />

      <Similars
        movieData={similarSeries}
        isMovieDataLoading={isLoading.similar}
        sectionTitle="You may also like"
        detailType="similarMovies"
        seeMoreButtonLink={`/SimilarSeries/${seriesID}/${dbIndex}`}
      />
    </div>
  );
}

// src/pages/Movies.jsx
import React, { useState, useEffect } from "react";
import axios from "axios";
import MediaSection from "../components/MediaSection";
import ShadPagination from "@/components/Pagination";

export default function Movies() {
  const BASE = import.meta.env.VITE_BASE_URL;

  const [movies, setMovies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortField, setSortField] = useState("updated_on");

  // Fetch Movies
  const fetchMovies = async () => {
    setIsLoading(true);
    try {
      const { data } = await axios.get(`${BASE}/api/movies`, {
        params: {
          sort_by: `${sortField}:desc`,
          page: currentPage,
          page_size: 24,
        },
      });
      setMovies(data.movies);
      setTotalCount(data.total_count);
    } catch (error) {
      console.error("Error fetching movies:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchMovies();
  }, [sortField, currentPage, BASE]);

  return (
    <div className="space-y-10">
      <MediaSection
        movieData={movies}
        isMovieDataLoading={isLoading}
        dataType="movies"
        sectionTitle="Browse Movies"
        setMovieFilter={setSortField}
        movieFilterVal={sortField}
        setMovieFilterVal={setSortField}
      />

      <ShadPagination
        currentPage={currentPage}
        totalCount={totalCount}
        pageSize={24}
        onPageChange={setCurrentPage}
      />
    </div>
  );
}

// src/pages/SearchResults.jsx
import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";
import MediaSection from "../components/MediaSection";
import ShadPagination from "@/components/Pagination";

export default function SearchResults() {
  const BASE = import.meta.env.VITE_BASE_URL;
  const location = useLocation();
  const query = new URLSearchParams(location.search).get("query");

  const [results, setResults] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);

  const fetchSearchResults = async () => {
    setIsLoading(true);
    try {
      const { data } = await axios.get(`${BASE}/api/search/`, {
        params: {
          query,
          page: currentPage,
          page_size: 20,
        },
      });
      setResults(data.results);
      setTotalCount(data.total_count);
    } catch (error) {
      console.error("Error fetching search results:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    if (query) fetchSearchResults();
  }, [query, currentPage]);

  return (
    <div className="space-y-10">
      <MediaSection
        movieData={results}
        isMovieDataLoading={isLoading}
        dataType="searchResult"
        sectionTitle={`Results for: ${query}`}
      />

      <ShadPagination
        currentPage={currentPage}
        totalCount={totalCount}
        pageSize={20}
        onPageChange={setCurrentPage}
      />
    </div>
  );
}

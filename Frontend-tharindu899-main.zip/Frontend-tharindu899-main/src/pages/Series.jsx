// src/pages/Series.jsx
import React, { useState, useEffect } from "react";
import axios from "axios";
import MediaSection from "@/components/MediaSection";
import ShadPagination from "@/components/Pagination";

export default function Series() {
  const BASE = import.meta.env.VITE_BASE_URL;

  const [series, setSeries] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortField, setSortField] = useState("updated_on");

  // Fetch TV Series
  const fetchSeries = async () => {
    setIsLoading(true);
    try {
      const { data } = await axios.get(`${BASE}/api/tvshows`, {
        params: {
          sort_by: `${sortField}:desc`,
          page: currentPage,
          page_size: 24,
        },
      });
      setSeries(data.tv_shows);
      setTotalCount(data.total_count);
    } catch (error) {
      console.error("Error fetching series:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchSeries();
  }, [sortField, currentPage, BASE]);

  return (
    <div className="space-y-10">
      <MediaSection
        movieData={series}
        isMovieDataLoading={isLoading}
        dataType="series"
        sectionTitle="Browse Series"
        setMovieFilter={setSortField}
        movieFilterVal={sortField}
        setMovieFilterVal={setSortField}
      />

      <ShadPagination
        currentPage={currentPage}
        totalCount={totalCount}
        pageSize={24}
        onPageChange={setCurrentPage}
      />
    </div>
  );
}

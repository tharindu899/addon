import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, Play, Send } from "lucide-react";


export default function QualityTab({
  qualities,
  selectedQuality,
  setSelectedQuality,
  telegramByQuality,
  tmdbId,
  seasonNumber,
  episodeNumber,
  db_index,

}) {
  const BASE = import.meta.env.VITE_BASE_URL;
  const botUsername = import.meta.env.VITE_BOT_USERNAME;

  const cleanBotUsername = botUsername?.replace(/^@/, "");

  // Detect platform
  const isAndroid = /android/i.test(navigator.userAgent);
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);

  return (
    <Tabs value={selectedQuality} onValueChange={setSelectedQuality}>
      <TabsList className="flex flex-wrap border border-[--border] md:flex-nowrap gap-2 overflow-x-auto no-scrollbar p-1 bg-[--muted]/10 rounded-lg">
        {qualities.map((quality) => (
          <TabsTrigger
            key={quality}
            value={quality}
            className="capitalize px-4 py-2 text-sm rounded-md bg-transparent text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground data-[state=active]:border data-[state=active]:border-zinc-700 data-[state=active]:bg-[--primary-foreground] data-[state=active]:text-[--primary]"
          >
            {quality}
          </TabsTrigger>
        ))}
      </TabsList>

      {qualities.map((quality) => (
        <TabsContent key={quality} value={quality} className="space-y-4">
          {telegramByQuality[quality]?.map((file, index) => {
            const downloadUrl = `${BASE}/dl/${file.id}/${encodeURIComponent(file.name)}`;

            let playUrl = downloadUrl;
            if (isAndroid) {
              playUrl = `intent:${downloadUrl}#Intent;type=video/x-matroska;action=android.intent.action.VIEW;end;`;
            } else if (isIOS) {
              playUrl = `vlc://${downloadUrl}`;
            }


            const telegramUrl = seasonNumber
            ? `https://t.me/${cleanBotUsername}?start=file_${tmdbId}_${db_index}_${seasonNumber}_${episodeNumber}_${quality}`
            : `https://t.me/${cleanBotUsername}?start=file_${tmdbId}_${db_index}_${quality}`;
          

            return (
              <div
                key={index}
                className="bg-[--muted]/20 border border-[--border] rounded-xl p-4 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                  <span className="text-sm font-medium text-[--foreground] truncate">
                    {file.name}
                  </span>
                  <Badge variant="secondary" className="w-fit">
                    {file.size}
                  </Badge>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button asChild size="sm">
                    <a href={downloadUrl} target="_blank" rel="noopener noreferrer">
                      <Download className="w-4 h-4 mr-1" />
                      Download
                    </a>
                  </Button>

                  <Button variant="outline" asChild size="sm">
                    <a href={playUrl} target="_blank" rel="noopener noreferrer">
                      <Play className="w-4 h-4 mr-1" />
                      Play
                    </a>
                  </Button>

                  <Button variant="outline" asChild size="sm">
                    <a href={telegramUrl} target="_blank" rel="noopener noreferrer">
                      <Send className="w-4 h-4 mr-1" />
                      Telegram
                    </a>
                  </Button>
                </div>
              </div>
            );
          })}
        </TabsContent>
      ))}
    </Tabs>
  );
}

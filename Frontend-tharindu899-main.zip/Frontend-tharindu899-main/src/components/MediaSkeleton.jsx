import React, { useEffect, useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";

const MediaSkeleton = () => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7">
      {[...Array(14)].map((_, index) => (
        <div
          key={index}
          className="relative overflow-hidden rounded-[var(--radius-lg)] shadow-sm w-full max-w-[200px] mx-auto"
          style={{
            backgroundColor: "var(--card)",
            boxShadow: "0 1px 2px 0 rgba(0, 0, 0, 0.05)"
          }}
        >
          {/* Poster */}
          <Skeleton className="aspect-[2/3] w-full rounded-[var(--radius-lg)]" />

          {/* Year Badge */}
          <div className="absolute top-2 right-2 z-10">
            <Skeleton className="h-5 w-10 rounded-full bg-muted-foreground/20" />
          </div>

          {/* Overlay content (hidden on mobile) */}
          {!isMobile && (
            <div
              className="absolute inset-0 flex flex-col justify-end p-3 z-10"
              style={{
                background: "linear-gradient(to top, var(--background) 30%, transparent 100%)"
              }}
            >
              <Skeleton className="h-4 w-3/4 mb-1.5 rounded-sm bg-muted-foreground/20" />
              <div className="flex items-center space-x-2">
                <Skeleton className="h-3 w-10 rounded-sm bg-muted-foreground/20" />
                <Skeleton className="h-3 w-12 rounded-sm bg-muted-foreground/20" />
                <Skeleton className="h-3 w-10 rounded-sm bg-muted-foreground/20" />
              </div>
              <div className="flex gap-1.5 mt-2">
                <Skeleton className="h-4 w-12 rounded-full bg-muted-foreground/20" />
                <Skeleton className="h-4 w-12 rounded-full bg-muted-foreground/20" />
              </div>
            </div>
          )}

          {/* Title skeleton below card on mobile */}
          {isMobile && (
            <div className="mt-2 px-1">
              <Skeleton className="h-4 w-3/4 mb-1 rounded-sm bg-muted-foreground/20" />
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default MediaSkeleton;

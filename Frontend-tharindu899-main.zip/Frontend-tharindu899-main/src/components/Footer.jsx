// components/Footer.tsx
import React from "react";
import { Link } from "react-router-dom";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Send } from "lucide-react";

const TG_URL = import.meta.env.VITE_TG_URL;
const SITENAME = import.meta.env.VITE_SITENAME;

export default function Footer() {
  return (
 
    <footer className="border-t border-muted px-4 py-3 md:px-10">
      <div className="container mx-auto flex flex-col md:flex-row gap-10 md:gap-0 justify-between text-muted-foreground">
        {/* Left Section */}
        <div className="w-full md:w-1/3 space-y-4">
          <h1 className="text-2xl font-bold text-foreground">
            <a href="/" className="hover:underline">
              {SITENAME}
            </a>
          </h1>
          <p className="text-sm">
            This site does not store any files on its server. It only links to media files hosted on Telegram.
          </p>
          <a
            href={TG_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 mt-4 hover:text-primary transition-colors"
          >
            <Send className="w-5 h-5" />
            Join us on Telegram
          </a>
        </div>

        {/* Middle Section */}
        <div className="w-full md:w-1/3 space-y-4">
          <h2 className="text-xl font-semibold text-foreground border-b border-primary pb-1 inline-block">
            What We Have
          </h2>
          <div className="flex flex-wrap gap-2">
            {["Movies", "TV Shows", "Anime", "K-Drama"].map((item) => (
              <Badge key={item} variant="secondary" className="text-sm px-4 py-1">
                {item}
              </Badge>
            ))}
          </div>
        </div>

        {/* Right Section */}
        <div className="w-full md:w-1/3 space-y-4">
          <h2 className="text-xl font-semibold text-foreground border-b border-primary pb-1 inline-block">
            Quick Menu
          </h2>
          <ul className="flex flex-col gap-3 text-sm">
            <li>
              <Link to="/" className="hover:text-primary transition-colors">
                Home
              </Link>
            </li>
            <li>
              <Link to="/Movies" className="hover:text-primary transition-colors">
                Movies
              </Link>
            </li>
            <li>
              <Link to="/Series" className="hover:text-primary transition-colors">
                Series
              </Link>
            </li>
          </ul>
        </div>
      </div>

      {/* Bottom */}
      <Separator className="my-6" />
      <div className="container mx-auto text-center text-xs text-muted-foreground flex flex-col sm:flex-row items-center justify-center gap-2">
        <div className="inline-flex items-center gap-2">
          <span className="relative w-5 h-5 flex items-center justify-center rounded-full border border-muted-foreground">
            <span className="text-xs font-semibold">C</span>
          </span>
          <span className="uppercase">{SITENAME}. All Rights Reserved.</span>
        </div>
      </div>
    </footer>
  );
}

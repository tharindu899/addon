import React, { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useLocation } from "react-router-dom";
import { LazyLoadImage } from "react-lazy-load-image-component";

import { ModeToggle } from "@/components/mode-toggle";

import "react-lazy-load-image-component/src/effects/black-and-white.css";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

import { Search, X, Home, Star, Film, Tv } from "lucide-react";

export default function Nav() {
    const BASE = import.meta.env.VITE_BASE_URL;
    const SITENAME = import.meta.env.VITE_SITENAME;

    const [open, setOpen] = useState(false);
    const [query, setQuery] = useState("");
    const [debouncedVal, setDebouncedVal] = useState("");
    const [searchResult, setSearchResult] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [navStatus, setNavStatus] = useState("Home");
    const location = useLocation();

    const closeSearchResultsDropDown = useRef();

    useEffect(() => {
        const path = location.pathname;
        if (path === "/") setNavStatus("Home");
        else if (path.startsWith("/mov") || path.startsWith("/Movies")) setNavStatus("Movies");
        else if (path.startsWith("/ser") || path.startsWith("/Series")) setNavStatus("Series");
    }, [location.pathname]);

    useEffect(() => {
        if (!debouncedVal) return;
        setIsLoading(true);
        fetch(`${BASE}/api/search/?query=${debouncedVal}&page=1`)
            .then((res) => res.json())
            .then((data) => {
                setSearchResult(data.results);
                setIsLoading(false);
            })
            .catch(() => setIsLoading(false));
    }, [debouncedVal]);

    useEffect(() => {
        const timer = setTimeout(() => setDebouncedVal(query), 500);
        return () => clearTimeout(timer);
    }, [query]);

    useEffect(() => {
        const handler = (event) => {
            if (
                closeSearchResultsDropDown.current &&
                !closeSearchResultsDropDown.current.contains(event.target)
            ) {
                setDebouncedVal("");
            }
        };
        document.addEventListener("mousedown", handler);
        return () => document.removeEventListener("mousedown", handler);
    }, []);

    const navItems = [
        { icon: Home, name: "Home" },
        { icon: Film, name: "Movies" },
        { icon: Tv, name: "Series" },
    ];

    return (
        <div className="fixed z-50 top-0 left-0 right-0 bg-background/80 backdrop-blur-md border-b px-4 py-3 md:px-10">
            <div className="flex items-center justify-between gap-3">
                <Link
                    to="/"
                    className="hidden md:flex items-center gap-2 text-primary font-bold text-2xl uppercase"
                >
                    {SITENAME}
                </Link>

                {/* Mobile Menu Button */}
                <div className="block md:hidden">
                    <Sheet open={open} onOpenChange={setOpen}>
                        <SheetTrigger asChild>
                            <Button variant="ghost" size="icon" onClick={() => setOpen(true)}>
                                <div className="flex flex-col gap-1">
                                    <div className="h-[2px] w-6 bg-muted-foreground" />
                                    <div className="h-[2px] w-4 bg-muted-foreground" />
                                    <div className="h-[2px] w-2 bg-muted-foreground" />
                                </div>
                            </Button>
                        </SheetTrigger>
                        <SheetContent side="left" className="p-4 w-64">
                            <div className="space-y-4 mt-6">
                                {navItems.map((item, index) => (
                                    <Link
                                    key={index}
                                    to={item.name === "Home" ? "/" : `/${item.name}`}
                                    onClick={() => {
                                      setNavStatus(item.name);
                                      setOpen(false); // close sheet
                                    }}
                                    className={`flex items-center gap-3 px-2 py-2 rounded-md text-md ${
                                      navStatus === item.name
                                        ? "text-primary font-semibold"
                                        : "text-muted-foreground hover:text-primary"
                                    }`}
                                  >
                                    <item.icon className="w-5 h-5" />
                                    {item.name}
                                  </Link>
                                ))}
                            </div>
                        </SheetContent>
                    </Sheet>
                </div>

                {/* Desktop Navigation */}
                <nav className="hidden md:flex gap-8">
                    {navItems.map((item, index) => (
                        <Link
                            key={index}
                            to={item.name === "Home" ? "/" : `/${item.name}`}
                            onClick={() => setNavStatus(item.name)}
                            className={`flex flex-col items-center transition-all duration-300 ${navStatus === item.name
                                ? "text-primary scale-105"
                                : "hover:text-primary hover:scale-105 text-muted-foreground"
                                }`}
                        >
                            <item.icon className="w-5 h-5" />
                            <span className="text-xs">{item.name}</span>
                        </Link>
                    ))}
                </nav>

                {/* Search Input + Mode Toggle */}
                <div className="flex items-center gap-2 w-full md:w-1/2">
                    <form
                        onSubmit={(e) => e.preventDefault()}
                        className="relative w-full"
                        ref={closeSearchResultsDropDown}
                    >
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder="Search..."
                                className="pl-10 pr-4 py-5 text-sm"
                            />
                            {debouncedVal && (
                                <div className="absolute top-14 z-50 w-full bg-popover border border-border rounded-lg shadow-md overflow-hidden max-h-[70dvh]">
                                    <ScrollArea className="max-h-[70dvh] overflow-y-auto">
                                        {isLoading ? (
                                            <div className="p-4 text-muted-foreground text-sm">Searching...</div>
                                        ) : searchResult.length === 0 ? (
                                            <div className="p-4 text-muted-foreground text-sm">No results found</div>
                                        ) : (
                                            <>
                                                {(searchResult.slice(0, 10)).map((result, index) => (
                                                    <Link
                                                        key={index}
                                                        to={
                                                            result.media_type === "movie"
                                                                ? `/Movie/${result.tmdb_id}/${result.db_index}`
                                                                : `/Series/${result.tmdb_id}/${result.db_index}`
                                                        }
                                                        className="flex items-center gap-3 p-3 hover:bg-muted transition-colors border-b last:border-none"
                                                        onClick={() => {
                                                            setQuery("");
                                                            setDebouncedVal("");
                                                        }}
                                                    >
                                                        <div className="flex gap-3 w-full items-start">
                                                            {/* Poster */}
                                                            <div className="w-14 aspect-[2/3] rounded-md overflow-hidden bg-muted shrink-0">
                                                                <LazyLoadImage
                                                                    src={result.poster || result.backdrop}
                                                                    alt={result.title}
                                                                    effect="black-and-white"
                                                                    className="w-full h-full object-cover "
                                                                />
                                                            </div>

                                                            {/* Info */}
                                                            <div className="flex flex-col overflow-hidden flex-1">
                                                                {/* Title */}
                                                                <span className="font-semibold text-sm text-foreground line-clamp-1">
                                                                    {result.title || result.name}
                                                                </span>

                                                                {/* Description */}
                                                                {result.description && (
                                                                    <span className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                                                                        {result.description}
                                                                    </span>
                                                                )}

                                                                {/* Metadata */}
                                                                <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                                                                    <span className="capitalize">{result.media_type}</span>
                                                                    {result.rating && (
                                                                        <span className="flex items-center gap-1 text-yellow-500">
                                                                            <Star className="w-3.5 h-3.5 fill-yellow-500 stroke-yellow-500" />
                                                                            {result.rating.toFixed(1)}
                                                                        </span>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>


                                                    </Link>
                                                ))}

                                                {searchResult.length > 5 && (
                                                    <div className="flex justify-center p-2">
                                                        <Button
                                                            variant="outline"
                                                            className="w-full text-sm"
                                                            onClick={() => {
                                                                // Optional: set query to show all, or redirect to a full search results page
                                                                window.location.href = `/search?query=${debouncedVal}`;
                                                            }}
                                                        >
                                                            Show more results
                                                        </Button>
                                                    </div>
                                                )}
                                            </>
                                        )}
                                    </ScrollArea>
                                </div>
                            )}



                        </div>
                    </form>

                    {/* Theme Toggle Button */}
                    <ModeToggle />
                </div>

            </div>
        </div>
    );
}

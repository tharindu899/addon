import React, { useState, useEffect } from "react";
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";

import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectValue,
  SelectItem,
} from "@/components/ui/select";

import {
  Play,
  Clock,
  Calendar,
  Languages,
  Star,
} from "lucide-react";
import QualityTab from "./QualityTab";

export default function DetailsSections({
  movieData,
  episodes,
  isMovieDataLoading,
  isEpisodesLoading,
  detailType,
  seasonNumber,
  setSeasonNumber,
  setEpisodeNumber,
}) {
  const [selectedQuality, setSelectedQuality] = useState(null);
  const [episodeQualityTab, setEpisodeQualityTab] = useState({});

  const telegramByQuality = {};
  if (movieData?.telegram) {
    movieData.telegram.forEach((file) => {
      if (!telegramByQuality[file.quality]) {
        telegramByQuality[file.quality] = [];
      }
      telegramByQuality[file.quality].push(file);
    });
  }
  // Fixed: Sort qualities numerically when creating the array
  const qualities = Object.keys(telegramByQuality).sort((a, b) => {
    const numA = parseInt(a.replace(/\D/g, ""), 10);
    const numB = parseInt(b.replace(/\D/g, ""), 10);
    return numA - numB;
  });

  useEffect(() => {
    if (qualities.length > 0) setSelectedQuality(qualities[0]);
  }, [movieData]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <section className="mt-20 container px-4">
      {/* loading section */}
      {isMovieDataLoading ? (
        <>
          <div className="hidden md:block w-full h-[50vh] rounded-xl overflow-hidden relative">
            <Skeleton className="w-full h-full rounded-xl opacity-20" />
            <div className="absolute inset-0 bg-gradient-to-b from-background via-muted" />
          </div>

          <div className="mt-4 md:-mt-28 relative z-10">
            <div className="flex flex-col md:flex-row gap-8 items-center md:items-start text-center md:text-left">
              <div className="w-55 md:-mt-12 shrink-0">
                <Skeleton className="w-full h-[300px] md:h-[350px] rounded-xl shadow-lg mx-auto md:mx-0" />
              </div>

              <div className="space-y-4 w-full text-[--foreground]">
                <Skeleton className="h-10 w-2/3 md:w-1/2 mx-auto md:mx-0" />
                <div className="flex flex-wrap justify-center md:justify-start gap-4">
                  <Skeleton className="h-5 w-16" />
                  <Skeleton className="h-5 w-12" />
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-5 w-24" />
                </div>
                <Skeleton className="h-20 w-full" />
                <div className="flex flex-wrap justify-center md:justify-start gap-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-8 w-16 rounded-full" />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        <>
          {/* Backdrop  */}
          <div className="hidden md:block w-full h-[50vh] rounded-xl overflow-hidden relative">
            <LazyLoadImage
              src={movieData.backdrop || "/placeholder.svg"}
              alt={movieData.title}
              effect="blur"
              className="w-full h-full object-cover object-center rounded-xl"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/40 to-black/90" />
          </div>

          {/* Metadata with Poster */}
          <div className="mt-4 md:-mt-28 relative z-10">
            <div className="flex flex-col md:flex-row gap-8 items-center md:items-start text-center md:text-left">
              <div className="w-55 md:-mt-12 shrink-0">
                <LazyLoadImage
                  src={movieData.poster || "/placeholder.svg"}
                  alt={movieData.title}
                  effect="blur"
                  className="rounded-xl shadow-lg w-full h-auto object-cover mx-auto md:mx-0"
                />
              </div>

              <div className="text-[--foreground] space-y-6 ">
                <h1 className="text-3xl md:text-4xl md:mt-26 font-bold">
                  {movieData.title}
                </h1>

                <div className="flex flex-wrap justify-center md:justify-start gap-4 text-sm text-[--muted-foreground]">
                  {movieData.rating != null && (
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      {movieData.rating.toFixed(1)}
                    </div>
                  )}
                  {movieData.release_year && (
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {movieData.release_year}
                    </div>
                  )}
                  {movieData.runtime && detailType === "movie" && (
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {movieData.runtime} min
                    </div>
                  )}
                  {detailType === "series" && (
                    <div className="flex items-center gap-2">
                      <span>{movieData.total_seasons} Seasons</span>
                      <span>|</span>
                      <span>{movieData.total_episodes} Episodes</span>
                    </div>
                  )}
                  {movieData.languages?.length > 0 && (
                    <div className="flex items-center gap-1">
                      <Languages className="w-4 h-4" />
                      {movieData.languages.join(", ")}
                    </div>
                  )}
                </div>

                <p className="text-[--muted-foreground]">
                  {movieData.description}
                </p>

                <div className="flex flex-wrap justify-center md:justify-start gap-2">
                  {movieData.genres?.map((genre, index) => (
                    <Badge key={index} variant="outline">
                      {genre}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Qualities button for Movies Only */}
          {detailType === "movie" && qualities.length > 0 && (
            <div className="mt-10 space-y-4">
              <h3 className="text-lg font-semibold text-[--foreground]">
                Available Qualities
              </h3>
              <QualityTab
                qualities={qualities}
                selectedQuality={selectedQuality}
                setSelectedQuality={setSelectedQuality}
                telegramByQuality={telegramByQuality}
                tmdbId={movieData.tmdb_id}
                db_index={movieData.db_index}
              />
            </div>
          )}

          {/* Episode, Season, Qualities for Series Only */}
          {detailType === "series" && (
            <div className="mt-12 mb-2">
              <div className="flex flex-row justify-between items-center mb-4 gap-4">
                <h2 className="text-2xl font-bold text-[--foreground]">
                  Episodes
                </h2>
                <Select
                  value={seasonNumber.toString()}
                  onValueChange={(value) => setSeasonNumber(Number(value))}
                >
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Season" />
                  </SelectTrigger>
                  <SelectContent>
                    {movieData.seasons
                      ?.sort((a, b) => a.season_number - b.season_number)
                      .map((season) => (
                        <SelectItem
                          key={season.season_number}
                          value={season.season_number.toString()}
                        >
                          Season {season.season_number}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {isEpisodesLoading ? (
                <div className="grid grid-cols-1 gap-2">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <Skeleton key={i} className="h-10 md:h-14 rounded-md" />
                  ))}
                </div>
              ) : (
                <Accordion type="single" collapsible className="space-y-4 ">
                  {episodes
                    .sort((a, b) => a.episode_number - b.episode_number)
                    .map((episode) => {
                      const telegramByQuality = {};
                      if (episode.telegram) {
                        episode.telegram.forEach((file) => {
                          if (!telegramByQuality[file.quality]) {
                            telegramByQuality[file.quality] = [];
                          }
                          telegramByQuality[file.quality].push(file);
                        });
                      }

                      const epQualities = Object.keys(telegramByQuality).sort(
                        (a, b) => {
                          const numA = parseInt(a.replace(/\D/g, ""), 10);
                          const numB = parseInt(b.replace(/\D/g, ""), 10);
                          return numA - numB;
                        }
                      );

                      return (
                        <AccordionItem
                          key={episode.episode_number}
                          value={`ep-${episode.episode_number}`}
                          className="border rounded-lg "
                        >
                          <AccordionTrigger className="px-4 py-3  text-foreground">
                            <div className="flex items-center gap-2">
                              <Play className="w-4 h-4 text-muted-foreground" />
                              <span className="font-semibold">
                                E{episode.episode_number}: {episode.title}
                              </span>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent className="p-2 -mt-4">
                            <p className="text-sm text-muted-foreground mb-4">
                              {episode.description}
                            </p>

                            {epQualities.length > 0 ? (
                              <QualityTab
                                qualities={epQualities}
                                selectedQuality={
                                  episodeQualityTab[episode.episode_number] ||
                                  epQualities[0]
                                }
                                setSelectedQuality={(val) =>
                                  setEpisodeQualityTab((prev) => ({
                                    ...prev,
                                    [episode.episode_number]: val,
                                  }))
                                }
                                telegramByQuality={telegramByQuality}
                                tmdbId={movieData.tmdb_id}
                                db_index={movieData.db_index}
                                seasonNumber={seasonNumber}
                                episodeNumber={episode.episode_number}
                              />
                            ) : (
                              <p className="text-sm text-muted-foreground">
                                No downloads available for this episode.
                              </p>
                            )}
                          </AccordionContent>
                        </AccordionItem>
                      );
                    })}
                </Accordion>
              )}
            </div>
          )}
        </>
      )}
    </section>
  );
}

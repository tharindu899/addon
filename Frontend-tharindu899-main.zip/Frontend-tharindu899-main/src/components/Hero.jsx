import React from "react";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { LazyLoadImage } from "react-lazy-load-image-component";
import { Autoplay, Navigation, A11y } from "swiper/modules";
import {
  ChevronLeft,
  ChevronRight,
  StarIcon,
  PlayCircleIcon,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

import "swiper/css";
import "react-lazy-load-image-component/src/effects/black-and-white.css";

export default function Hero({ movieData, isMovieDataLoading }) {
  if (isMovieDataLoading) {
    return (
      <div className="pt-20">
        <Skeleton className="rounded-2xl aspect-video md:h-[500px] w-full" />
      </div>
    );
  }

  return (
    <div className="pt-20">
      <Swiper
        modules={[Autoplay, Navigation, A11y]}
        loop
        grabCursor
        autoplay={{
          delay: 5000,
          disableOnInteraction: false,
          pauseOnMouseEnter: true,
        }}
        navigation={{
          prevEl: ".heroSlidePrev",
          nextEl: ".heroSlideNext",
        }}
        keyboard={{ enabled: true }}
        spaceBetween={30}
      >
        {movieData.map((movie, index) => (
          <SwiperSlide key={index}>
            <div className="relative">
              {/* Banner Image */}
              <div className="rounded-2xl overflow-hidden aspect-video md:h-[420px] md:aspect-auto">
                <LazyLoadImage
                  src={movie.backdrop}
                  alt={movie.title}
                  className="w-full h-full object-cover"
                  effect="black-and-white"
                />
              </div>

              {/* Content Overlay */}
              <div className="absolute bottom-4 left-4 sm:left-8 right-4 z-10 flex flex-col gap-2 text-[var(--muted-foreground)]">
                {/* Title */}
                {movie.title && (
                  <h1 className="line-clamp-1 text-xl sm:text-3xl md:text-4xl font-bold text-card-foreground">
                    {movie.title}
                  </h1>
                )}

                {/* Meta Info */}
                <div className="hidden sm:flex items-center gap-2 text-xs md:text-sm font-light text-card-foreground/90">
                  {movie.release_year && <span>{movie.release_year}</span>}
                  <span>•</span>
                  <span className="uppercase">
                    {movie.languages
                      .map(
                        (lang) => lang.charAt(0).toUpperCase() + lang.slice(1)
                      )
                      .join("-")}
                  </span>
                  <span>|</span>
                  <span>{movie.rip}</span>
                </div>

                {/* Genres */}
                <div className="hidden md:flex gap-2 flex-wrap">
                  {movie.genres.map((genre, i) => (
                    <Badge key={i} className="text-xs capitalize ">
                      {genre}
                    </Badge>
                  ))}
                </div>

                {/* Description */}
                {movie.description && (
                  <p className="line-clamp-2 text-xs sm:text-sm w-[90%] text-card-foreground/90">
                    {movie.description}
                  </p>
                )}

                {/* Buttons */}
                <div className="flex items-center gap-3 mt-2 flex-wrap">
                  <Link to={`/movie/${movie.tmdb_id}/${movie.db_index}`} className="no-underline">
                    <Button variant="default" className="gap-2 rounded-full">
                      <PlayCircleIcon size={18} />
                      Watch
                    </Button>
                  </Link>
                  {movie.rating > 0 && (
                    <div className="flex items-center gap-1 bg-[var(--secondary)] px-3 py-1 rounded-full text-yellow-400 text-sm">
                      <StarIcon size={16} fill="currentColor" />
                      <span className="text-xs sm:text-sm">
                        {movie.rating.toFixed(1)}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>

      {/* Navigation buttons (optional if navigation is enabled by Swiper) */}
      {/* 
      <div className="flex items-center gap-4 mt-5 pl-4 sm:pl-8">
        <button className="heroSlidePrev text-[var(--muted-foreground)] p-2 rounded-full hover:bg-[var(--secondary)] transition">
          <ChevronLeft size={28} />
        </button>
        <button className="heroSlideNext text-[var(--muted-foreground)] p-2 rounded-full hover:bg-[var(--secondary)] transition">
          <ChevronRight size={28} />
        </button>
      </div>
      */}
    </div>
  );
}

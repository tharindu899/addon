import React from "react";
import { Button } from "@/components/ui/button";
import MediaCard from "./MediaCard";
import MediaSkeleton from "./MediaSkeleton";

export default function MediaSection({
  sectionTitle,
  dataType,
  movieData,
  isMovieDataLoading,
  movieFilterVal,
  setMovieFilterVal,
  setMovieFilter,
}) {
  const filters = [
    { name: "Latest Post", value: "updated_on" },
    { name: "Top Rated", value: "rating" },
    { name: "New Release", value: "release_year" },
  ];

  const showFilters = dataType === "movies" || dataType === "series";

  return (
    <div className="space-y-6 mt-20">
      {/* Title & Filters */}
      <div className="flex items-center flex-wrap gap-4 px-4">
        <div className="border-l-4 pl-4 border-primary">
          <h2 className="uppercase text-sm font-bold text-foreground sm:text-base">
            {sectionTitle}
          </h2>
        </div>

        {showFilters && (
          <div className="flex flex-wrap items-center gap-3">
            {filters.map(({ name, value }) => (
              <Button
                key={value}
                variant={value === movieFilterVal ? "default" : "secondary"}
                className="rounded-full text-xs sm:text-sm px-3"
                onClick={() => {
                  setMovieFilterVal(value);
                  setMovieFilter(value);
                }}
              >
                {name}
              </Button>
            ))}
          </div>
        )}
      </div>

      {/* Media Grid */}
      {!isMovieDataLoading ? (
        <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
          {movieData.map((movie, index) => (
            <MediaCard key={movie.id || index} media={movie} />
          ))}
        </div>
      ) : (
        <MediaSkeleton />
      )}
    </div>
  );
}

import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Star, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";

const formatRuntime = (minutes) => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours}h ${mins}m`;
};

const MediaCard = ({ media }) => {
  // Determine if current media is a movie or tv
  const isMovie = media.media_type === "movie";
  const detailsPath = isMovie
    ? `/Movie/${media.tmdb_id}/${media.db_index}`
    : `/Series/${media.tmdb_id}/${media.db_index}`;

  const [imageLoaded, setImageLoaded] = useState(false);
  const [shouldLoad, setShouldLoad] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const cardRef = useRef(null);

  // Create a language display string from the languages array, if available.
  const languageDisplay =
    media.languages && Array.isArray(media.languages) && media.languages.length
      ? media.languages.join(" / ")
      : null;

  // Flags for runtime and seasons info
  const hasRuntime = "runtime" in media;
  const hasTotalSeasons = "total_seasons" in media;

  // Intersection Observer for lazy loading
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShouldLoad(true);
          observer.disconnect();
        }
      },
      { rootMargin: "400px 0px", threshold: 0.01 }
    );

    if (cardRef.current) observer.observe(cardRef.current);
    return () => observer.disconnect();
  }, []);

  // Check if view is mobile by monitoring window width
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth <= 768);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  return (
    <Link
      ref={cardRef}
      to={detailsPath}
      className="block max-w-[200px] w-full mx-auto transition-all duration-300 hover:scale-[1.02] hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-[var(--radius-lg)]"
    >
      <div className="relative aspect-[2/3] overflow-hidden rounded-[var(--radius-lg)] bg-[var(--card)] text-[var(--card-foreground)] shadow-sm group">
        {/* Skeleton fallback */}
        {(!shouldLoad || !imageLoaded) && (
          <div className="absolute inset-0 z-0">
            <Skeleton className="w-full h-full rounded-[var(--radius-lg)]" />
          </div>
        )}

        {/* Poster */}
        {shouldLoad && (
          <LazyLoadImage
            src={media.poster || "/placeholder.svg"}
            alt={media.title}
            effect="blur"
            wrapperClassName="absolute inset-0 w-full h-full"
            className="w-full h-full object-cover object-center transition-transform duration-300 group-hover:scale-105 rounded-[var(--radius-lg)]"
            beforeLoad={() => setImageLoaded(false)}
            onLoad={() => setImageLoaded(true)}
            onError={(e) => {
              e.target.src = "/placeholder.svg";
              setImageLoaded(true);
            }}
          />
        )}

        {/* Mobile: Rip badge at bottom-left and Language badge at bottom-right */}
        {isMobile && (media.rip || languageDisplay) && (
          <>
            {media.rip && (
              <div className="absolute bottom-2 left-2 z-20">
                <Badge
                  className="text-[10px] px-2 py-0.5 font-medium shadow-sm"
                  style={{
                    backgroundColor: "var(--background)",
                    color: "var(--foreground)",
                    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.2)",
                  }}
                >
                  {media.rip}
                </Badge>
              </div>
            )}
            {languageDisplay && (
              <div className="absolute bottom-2 right-2 z-20">
                <Badge
                  className="text-[10px] px-2 py-0.5 font-medium shadow-sm"
                  style={{
                    backgroundColor: "var(--background)",
                    color: "var(--foreground)",
                    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.2)",
                  }}
                >
                  {languageDisplay}
                </Badge>
              </div>
            )}
          </>
        )}

        {/* Overlay for desktop view */}
        <div
          className={`absolute inset-0 p-3 flex flex-col justify-end z-10 transition-opacity duration-300 ${
            isMobile ? "opacity-0" : "opacity-0 group-hover:opacity-100"
          }`}
          style={{
            background: isMobile
              ? "transparent"
              : "linear-gradient(to top, var(--background) 30%, transparent 100%)",
          }}
        >
          {!isMobile && (
            <h3 className="font-semibold text-sm text-[var(--card-foreground)] line-clamp-2">
              {media.title}
            </h3>
          )}

          <div className="flex items-center mt-1 text-xs text-[var(--muted-foreground)]">
            {media.rating && (
              <>
                <Star className="h-3 w-3 mr-1 text-yellow-500 fill-yellow-500/20" />
                <span className="mr-2 text-[var(--card-foreground)/90]">
                  {media.rating.toFixed(1)}
                </span>
              </>
            )}
            {hasRuntime && (
              <>
                <Clock className="h-3 w-3 mr-1" />
                <span>{formatRuntime(media.runtime)}</span>
              </>
            )}
            {hasTotalSeasons && (
              <span className="ml-2">
                {media.total_seasons}{" "}
                {media.total_seasons === 1 ? "Season" : "Seasons"}
              </span>
            )}
          </div>

          <div className="flex flex-wrap gap-1 mt-2">
            {media.genres?.slice(0, 2).map((genre, idx) => (
              <Badge
                key={idx}
                variant="outline"
                className="text-[10px] px-1.5 py-0.5 font-normal border-[var(--muted)]"
                style={{
                  backgroundColor: "var(--muted)",
                  color: "var(--muted-foreground)",
                }}
              >
                {genre}
              </Badge>
            ))}
          </div>
        </div>

        {/* Year Badge */}
        {media.release_year && (
          <div className="absolute top-2 right-2 z-20">
            <Badge
              className="text-[10px] px-2 py-0.5 font-medium shadow-sm"
              style={{
                backgroundColor: "var(--primary)",
                color: "var(--primary-foreground)",
                boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
              }}
            >
              {media.release_year}
            </Badge>
          </div>
        )}
      </div>

      {/* Title below card on mobile */}
      {isMobile && (
        <h3 className="mt-2 text-sm font-semibold text-left text-[var(--card-foreground)] line-clamp-2">
          {media.title}
        </h3>
      )}
    </Link>
  );
};

export default MediaCard;

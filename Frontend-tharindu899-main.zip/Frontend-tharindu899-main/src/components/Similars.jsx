import React from "react";
import { Link } from "react-router-dom";
import MediaCard from "./MediaCard";
import { ArrowRight } from "lucide-react";
import MediaSkeleton from "./MediaSkeleton";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";

export default function HomeSection({
  sectionTitle,
  seeMoreButtonLink,
  movieData,
  isMovieDataLoading,
}) {
  return (
    <section className="space-y-6 mt-6">
      {/* Title & View All */}
      <div className="flex items-center justify-between">
        <div className="space-y-1.5">
          <h2 className="text-xl font-semibold tracking-tight text-foreground">
            {sectionTitle}
          </h2>
          <Separator className="w-16 h-1 bg-primary" />
        </div>

        <Button
          asChild
          variant="ghost"
          className="group px-3 py-1 h-auto text-sm text-muted-foreground hover:text-foreground"
        >
          <Link to={seeMoreButtonLink} className="flex items-center gap-1">
            <span>View all</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </Button>
      </div>

      {/* Media Grid */}
      <div className="relative">
        {isMovieDataLoading ? (
          <MediaSkeleton />
        ) : (
          <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7">
            {movieData.map((movie, index) => (
              <MediaCard key={movie.id || index} media={movie} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

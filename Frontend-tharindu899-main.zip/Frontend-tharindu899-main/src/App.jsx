import Home from "./pages/Home";
import Movies from "./pages/Movies";
import Series from "./pages/Series";
import SimilarSeries from "./pages/SimilarSeries";
import SimilarMovies from "./pages/SimilarMovies";
import MovieDetails from "./pages/MovieDetails";
import SeriesDetails from "./pages/SeriesDetails";
import SearchResults from "./pages/SearchResults";

import Nav from "./components/Nav";
import Footer from "./components/Footer";

import { BrowserRouter, Route, Routes } from "react-router-dom";





function App() {
  return (
    <BrowserRouter>
      <Nav />
      <div className="p-3 md:p-10">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Movies" element={<Movies />} />
          <Route path="/Series" element={<Series />} />
          <Route path="/Movie/:movieID/:dbIndex" element={<MovieDetails />} />
          <Route path="/Series/:seriesID/:dbIndex" element={<SeriesDetails />} />
          <Route path="/SimilarMovie/:movieID/:dbIndex" element={<SimilarMovies />} />
          <Route path="/SimilarSeries/:seriesID/:dbIndex" element={<SimilarSeries />} />
          <Route path="/search" element={<SearchResults />} />
        </Routes>
      </div>
      <Footer />
    </BrowserRouter>
  );
}

export default App;

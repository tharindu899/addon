from asyncio import Queue, Lock, create_task, sleep as asleep

from pyrogram import filters, Client
from pyrogram.enums.parse_mode import ParseMode
from pyrogram.types import Message
from pyrogram.errors import FloodWait

from Backend.logger import LOGGER
from Backend import db
from Backend.config import Telegram
from Backend.helper.metadata import metadata
from Backend.helper.pyro import clean_filename, get_readable_file_size, remove_urls
from themoviedb import aioTMDb


tmdb = aioTMDb(key=Telegram.TMDB_API, language="en-US", region="US")
file_queue = Queue()
db_lock = Lock()

async def process_file() -> None:
    while True:
        metadata_info, file_hash, channel, msg_id, size, title = await file_queue.get()
        async with db_lock:
            updated_id = await db.insert_media(
                metadata_info,
                hash=file_hash,
                channel=channel,
                msg_id=msg_id,
                size=size,
                name=title
            )
            if updated_id:
                LOGGER.info(f"{metadata_info.get('media_type')} updated with ID: {updated_id}")
            else:
                LOGGER.info("Update failed due to validation errors.")
        file_queue.task_done()


WORKER_COUNT = 1  # Adjust the number of workers if required
for _ in range(WORKER_COUNT):
    create_task(process_file())


@Client.on_message(filters.channel & (filters.document | filters.video))
async def file_receive_handler(bot: Client, message: Message) -> None:
    if str(message.chat.id) not in Telegram.AUTH_CHANNEL:
        await message.reply_text("Channel is not in AUTH_CHANNEL")
        return
    try:
        if message.video or message.document.mime_type.startswith("video/"):
            file = message.video or message.document
            title = message.caption.replace("\n", "\\n") if Telegram.USE_CAPTION else (file.file_name or file.file_id)
            msg_id = message.id
            file_hash = file.file_unique_id[:6]
            size = get_readable_file_size(file.file_size)
            channel = int(str(message.chat.id).replace("-100", ""))

            # Generate metadata using helper function
            metadata_info = await metadata(clean_filename(title), file)
            if metadata_info is None:
                return

            # Clean title from URLs and add extension if necessary
            title = remove_urls(title)
            if not title.endswith('.mkv'):
                title += '.mkv'

            await file_queue.put((metadata_info, file_hash, channel, msg_id, size, title))
        else:
            await message.reply_text("<blockquote>Not a supported file format.</blockquote>")
    except FloodWait as e:
        LOGGER.info(f"FloodWait encountered; sleeping for {e.value} seconds.")
        await asleep(e.value)
        await message.reply_text(
            text=f"Got Floodwait of {e.value} seconds",
            disable_web_page_preview=True,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as err:
        LOGGER.error(f"Error processing file: {err}")
        await message.reply_text("An error occurred while processing the file.")

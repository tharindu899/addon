from Backend.config import Telegram
from Backend import db
class ConfigManager:
    def __init__(self):
        self.config = {}


    async def load(self):
        # Load defaults from config.py (Telegram class)
        default_config = {
            key: getattr(Telegram, key)
            for key in dir(Telegram)
            if not key.startswith("__") and not callable(getattr(Telegram, key))
        }
        # Merge with stored values in the tracking DB.
        stored = await db.dbs["tracking"]["deployConfig"].find_one({"_id": Telegram.OWNER_ID})
        if stored:
            default_config.update(stored)
        self.config = default_config

    def get(self, key, default=None):
        return self.config.get(key, default)
    
    def __getattr__(self, key):
        try:
            return self.config[key]
        except KeyError:
            raise AttributeError(f"'ConfigManager' object has no attribute '{key}'")


config_manager = ConfigManager()

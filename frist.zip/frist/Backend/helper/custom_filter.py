from pyrogram.filters import create
from Backend.config_manager import config_manager

class CustomFilters:

    @staticmethod
    async def owner_filter(client, message):
        user = message.from_user or message.sender_chat
        uid = user.id
        return uid == config_manager.OWNER_ID

    owner = create(owner_filter)
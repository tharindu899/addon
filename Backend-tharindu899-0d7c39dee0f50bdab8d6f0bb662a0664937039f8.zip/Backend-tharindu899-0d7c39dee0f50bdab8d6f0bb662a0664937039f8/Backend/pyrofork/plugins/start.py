from asyncio import create_task, sleep as asleep, create_subprocess_exec, gather
from pyrogram import filters, Client, enums
from pyrogram.types import Message
from pyrogram.errors import FloodWait, UserIsBlocked, InputUserDeactivated
from os import path as ospath, execl as osexecl
from Backend.config import Telegram
from Backend.helper.custom_filter import CustomFilters
from Backend.logger import LOGGER
from Backend import db
from Backend.helper.encrypt import decode_string
from aiofiles import open as aiopen
import asyncio
import traceback
from urllib.parse import urlparse
from sys import executable



async def auto_delete(messages):
    await asleep(Telegram.AUTO_DELETE_TIME)
    for msg in messages:
        try:
            await msg.delete()
        except Exception as e:
            LOGGER.error(f"Error deleting message {msg.id}: {e}")
        await asleep(2)  

def parse_command_parts(command_part: str):
    # Remove prefix and split parts
    prefix = "file_"
    usr_cmd = command_part[len(prefix):].strip()
    parts = usr_cmd.split("_")

    if len(parts) == 3:
        tmdb_id, db_index, quality = parts
        return {
            "tmdb_id": int(tmdb_id),
            "db_index": int(db_index),
            "quality": quality
        }
    elif len(parts) == 4:
        tmdb_id, db_index, season, quality = parts
        return {
            "tmdb_id": int(tmdb_id),
            "db_index": int(db_index),
            "season": int(season),
            "quality": quality
        }
    elif len(parts) == 5:
        tmdb_id, db_index, season, episode, quality = parts
        return {
            "tmdb_id": int(tmdb_id),
            "db_index": int(db_index),
            "season": int(season),
            "episode": int(episode),
            "quality": quality
        }
    else:
        raise ValueError("Invalid command format.")


@Client.on_message(filters.command('start') & filters.private)
async def start(bot: Client, message: Message):
    user_id = message.from_user.id

    try:
        if not await db.present_user(user_id):
            await db.add_user(user_id)
    except Exception as e:
        LOGGER.warning(f"Failed to check/add user {user_id}: {e}")

    command_arg = message.text.partition('start ')[2].strip()
    if command_arg.startswith("file_"):
        try:
            params = parse_command_parts(command_arg)
        except ValueError as err:
            error_message = "Invalid command format for movie or TV show."
            LOGGER.error(f"Error parsing command '{command_arg}': {err}")
            await message.reply_text(error_message)
            return

        # Retrieve quality details based on provided parameters
        try:
            if "episode" in params:
                quality_details = await db.get_quality_details(
                    params["tmdb_id"], params["db_index"], params["quality"],
                    params["season"], params["episode"]
                )
            elif "season" in params:
                quality_details = await db.get_quality_details(
                    params["tmdb_id"], params["db_index"], params["quality"],
                    params["season"]
                )
            else:
                quality_details = await db.get_quality_details(
                    params["tmdb_id"], params["db_index"], params["quality"]
                )
        except Exception as e:
            LOGGER.error(f"Error retrieving quality details: {e}")
            await message.reply_text("Error retrieving media details.")
            return

        sent_messages = []
        for detail in quality_details:
            try:
                decoded_data = await decode_string(detail['id'])
            except Exception as e:
                LOGGER.error(f"Decoding error for id {detail['id']}: {e}")
                continue

            channel = f"-100{decoded_data['chat_id']}"
            msg_id = decoded_data['msg_id']
            name = detail.get('name', 'Unknown')
            if "\\n" in name and name.endswith(".mkv"):
                name = name.rsplit(".mkv", 1)[0].replace("\\n", "\n")

            try:
                file = await bot.get_messages(int(channel), int(msg_id))
                media = file.document or file.video
                caption = (
                    f"{name}\n\n> **Forward these files to your saved messages. "
                    f"These files will be deleted from the bot within {Telegram.AUTO_DELETE_TIME} sec**"
                )
                if media:
                    sent_msg = await message.reply_cached_media(
                        file_id=media.file_id,
                        caption=caption
                    )
                    sent_messages.append(sent_msg)
                    await asleep(1)
            except FloodWait as e:
                LOGGER.info(f"FloodWait encountered. Sleeping for {e.value} seconds.")
                await asleep(e.value)
                await message.reply_text(f"Got FloodWait of {e.value} seconds")
            except Exception as e:
                LOGGER.error(f"Error retrieving/sending media: {e}")
                await message.reply_text("Error retrieving media.")
        
        if sent_messages:
            create_task(auto_delete(sent_messages))
    else:
        await message.reply_text("Hello 👋")


@Client.on_message(filters.command('delete') & filters.private & CustomFilters.owner)
async def delete(bot: Client, message: Message):
    try:
        split_text = message.text.split()
        if len(split_text) != 2:
            return await message.reply_text("Use this format: /delete https://domain/Series/3123/1")
        
        url = split_text[1]
        parsed_url = urlparse(url)
        path_parts = parsed_url.path.split('/')
        
        if len(path_parts) >= 4 and path_parts[-3] in ('Series', 'Movie') and path_parts[-2].isdigit() and path_parts[-1].isdigit():
            media_type = path_parts[-3]
            tmdb_id = path_parts[-2]
            db_index = path_parts[-1]
            delete = await db.delete_document(media_type, int(tmdb_id), int(db_index))
            if delete:
                return await message.reply_text(f"{media_type} with ID {tmdb_id} has been deleted successfully from storage_{db_index}.")
            else:
                return await message.reply_text(f"ID {tmdb_id} wasn't found in the database.")
        else:
            return await message.reply_text("The URL format is incorrect.")
    
    except Exception as e:
        await message.reply_text(f"An error occurred: {str(e)}")


@Client.on_message(filters.command('log') & filters.private & CustomFilters.owner)
async def log(bot: Client, message: Message):
    try:
        path = ospath.abspath('log.txt')
        return await message.reply_document(
        document=path, quote=True, disable_notification=True
        )
    except Exception as e:
        LOGGER.info(f"An error occurred: {e}")


@Client.on_message(filters.command('caption') & filters.private & CustomFilters.owner)
async def toggle_caption(bot: Client, message: Message):

    try:
        Telegram.USE_CAPTION = not Telegram.USE_CAPTION
        await message.reply_text(f"Now Bot Uses {'Caption' if Telegram.USE_CAPTION else 'Filename'}")
    except Exception as e:
        print(f"An error occurred: {e}")

@Client.on_message(filters.command('tmdb') & filters.private & CustomFilters.owner)
async def toggle_tmdb(bot: Client, message: Message):

    try:
        Telegram.USE_TMDB = not Telegram.USE_TMDB
        await message.reply_text(f"Now Bot Uses {'TMDB' if Telegram.USE_TMDB else 'IMDB'}")
    except Exception as e:
        print(f"An error occurred: {e}")

@Client.on_message(filters.command('set') & filters.private & CustomFilters.owner)
async def set_id(bot: Client, message: Message):

    url_part = message.text.split()[1:]  # Skip the command itself

    try:
        if len(url_part) == 1:

            Telegram.USE_DEFAULT_ID = url_part[0]  # Get the first element
            await message.reply_text(f"Now Bot Uses Default URL: {Telegram.USE_DEFAULT_ID}")
        else:
            # Remove the default ID
            Telegram.USE_DEFAULT_ID = None
            await message.reply_text("Removed default ID.")
    except Exception as e:
        await message.reply_text(f"An error occurred: {e}")


@Client.on_message(filters.command('restart') & filters.private & CustomFilters.owner)
async def restart(bot: Client, message: Message):
    try:
        restart_message = await message.reply_text(
    '<blockquote>⚙️ Restarting Backend API... \n\n✨ Please wait as we bring everything back online! 🚀</blockquote>',
        quote=True,
        parse_mode=enums.ParseMode.HTML
        )
        LOGGER.info("Restart initiated by owner.")

        # Run the update script
        proc1 = await create_subprocess_exec('python3', 'update.py')
        await gather(proc1.wait())

        # Save restart message details for notification after restart
        async with aiopen(".restartmsg", "w") as f:
            await f.write(f"{restart_message.chat.id}\n{restart_message.id}\n")

        # Restart the bot process
        osexecl(executable, executable, "-m", "Backend")

    except Exception as e:
        LOGGER.error(f"Error during restart: {e}")
        await message.reply_text("**❌ Failed to restart. Check logs for details.**")

@Client.on_message(filters.command('broadcast') & filters.private & CustomFilters.owner)
async def broadcast_handler(bot: Client, message: Message):
    if message.reply_to_message:
        query = await db.full_userbase()
        broadcast_msg = message.reply_to_message

        total = 0
        successful = 0
        blocked = 0
        deleted = 0
        unsuccessful = 0

        pls_wait = await message.reply_text(
            "<blockquote>📣 <b>Broadcasting Message...</b>\nPlease wait, this might take a while.</blockquote>",
            quote=True,
            parse_mode=enums.ParseMode.HTML
        )

        for chat_id in query:
            try:
                await broadcast_msg.copy(chat_id)
                successful += 1
            except FloodWait as e:
                LOGGER.warning(f"FloodWait: Sleeping for {e.x} seconds.")
                await asyncio.sleep(e.x)
                try:
                    await broadcast_msg.copy(chat_id)
                    successful += 1
                except Exception as retry_error:
                    LOGGER.error(f"Retry after FloodWait failed for {chat_id}: {retry_error}")
                    unsuccessful += 1
            except UserIsBlocked:
                await db.del_user(chat_id)
                blocked += 1
            except InputUserDeactivated:
                await db.del_user(chat_id)
                deleted += 1
            except Exception as e:
                LOGGER.error(f"Broadcast failed for {chat_id}: {e}")
                traceback.print_exc()
                unsuccessful += 1
            total += 1
            await asyncio.sleep(0.2)

        status = f"""<blockquote><b>✅ Broadcast Completed</b>

📊 <b>Summary:</b>
👥 Total Users: <code>{total}</code>
✅ Successful: <code>{successful}</code>
⛔ Blocked: <code>{blocked}</code>
🗑️ Deleted: <code>{deleted}</code>
❌ Failed: <code>{unsuccessful}</code>
</blockquote>
"""
        return await pls_wait.edit(status)

    else:
        msg = await message.reply_text("<blockquote>❗ Please reply to a message you want to broadcast.</blockquote>")
        await asyncio.sleep(8)
        await msg.delete()
        

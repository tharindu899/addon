## Easily Deploy to Heroku

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1lzVa0kMJ2WQmlf1q0l6HOLe_Uch0hL-x)
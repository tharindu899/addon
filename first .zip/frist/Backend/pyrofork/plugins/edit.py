from Backend.helper.custom_filter import CustomFilters
from Backend.logger import LOGGER
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message, CallbackQuery
from urllib.parse import urlparse
from typing import Dict, Any, Optional, Tuple, Union, List
from Backend import db, user_data
import asyncio

# Helper to validate input values before updating the document.
def validate_input(field: str, new_value: str, media_type: str) -> Tuple[Union[str, int, float, List[str]], Optional[str]]:
    if field in ["title", "description", "status", "rip", "episode_title"]:
        if not new_value:
            return new_value, f"{field.capitalize()} cannot be empty."
        return new_value, None
    elif field in ["genres", "languages"]:
        items = [x.strip() for x in new_value.split(",") if x.strip()]
        if not items:
            return items, f"{field.capitalize()} must have at least one value."
        return items, None
    elif field == "rating":
        try:
            return float(new_value), None
        except ValueError:
            return new_value, "Rating must be a numeric value (e.g., 8.5)."
    elif field in ["release_year", "runtime", "total_seasons", "total_episodes"]:
        try:
            return int(new_value), None
        except ValueError:
            return new_value, f"{field.replace('_', ' ').capitalize()} must be an integer."
    elif field in ["poster", "backdrop"]:
        if new_value.startswith("http://") or new_value.startswith("https://"):
            return new_value, None
        else:
            return new_value, f"{field.capitalize()} must be a valid URL."
    return new_value, None

def create_view_keyboard(media_type: str, tmdb_id: int, db_index: int, current_path: str = "root", document: Optional[Dict[str, Any]] = None) -> InlineKeyboardMarkup:
    buttons = []
    if current_path == "root":
        editable_fields = [
            ("Title", "title"), ("Genres", "genres"), ("Description", "description"),
            ("Languages", "languages"), ("Rip", "rip"), ("Release Year", "release_year"),
            ("Poster", "poster"), ("Backdrop", "backdrop"), ("Rating", "rating")
        ]
        if media_type.lower() == "series":
            editable_fields += [("Status", "status"), ("Total Seasons", "total_seasons"), ("Total Episodes", "total_episodes")]
        edit_buttons = []
        for i in range(0, len(editable_fields), 2):
            row = []
            for j in range(2):
                if i + j < len(editable_fields):
                    text, field = editable_fields[i + j]
                    row.append(InlineKeyboardButton(f"{text}", callback_data=f"edit_{field}_{current_path}"))
            edit_buttons.append(row)
        buttons.extend(edit_buttons)
        if media_type.lower() == "series":
            buttons.append([InlineKeyboardButton("📺 Manage Seasons", callback_data="view_seasons")])
        buttons.append([
            InlineKeyboardButton("📤 Save", callback_data="save_changes"),
            InlineKeyboardButton("❌ Cancel", callback_data="cancel_edit")
        ])
    elif current_path == "seasons":
        if document and "seasons" in document:
            buttons += [
                [InlineKeyboardButton(f"Season {season['season_number']}", callback_data=f"view_season_{season['season_number']}")]
                for season in sorted(document["seasons"], key=lambda x: x["season_number"])
            ]
        buttons.append([InlineKeyboardButton("🔙 Back to Main", callback_data="view_root")])
    elif current_path.startswith("season_"):
        season_num = int(current_path.split("_")[1])
        if document and "seasons" in document:
            season = next((s for s in document["seasons"] if s["season_number"] == season_num), None)
            if season:
                episodes = sorted(season["episodes"], key=lambda x: x["episode_number"])
                for ep in episodes:
                    buttons.append([
                        InlineKeyboardButton(
                            f"Episode {ep['episode_number']}: {ep['title']}",
                            callback_data=f"edit_episode_title_{season_num}_{ep['episode_number']}"
                        )
                    ])
        buttons.append([InlineKeyboardButton("🔙 Back to Seasons", callback_data="view_seasons")])
    return InlineKeyboardMarkup(buttons)

def format_document_for_display(document: Dict[str, Any], media_type: str, current_path: str = "root") -> str:
    text = ""
    if current_path == "root":
        text += f"**> 🎬 {media_type.capitalize()} Details\n\n"
        text += f"> 📌 **Title:** `{document.get('title', 'N/A')}`\n"
        text += f"> 🆔 **TMDB ID:** `{document.get('tmdb_id', 'N/A')}`\n"
        text += f"> 📂 **DB Index:** `{document.get('db_index', 'N/A')}`\n"
        text += f"> 🖼️ **Poster:** {document.get('poster', 'N/A')}\n"
        text += f"> 🌆 **Backdrop:** {document.get('backdrop', 'N/A')}\n"
        text += f"> 📝 **Description:** {document.get('description', 'N/A')}\n"
        text += f"> 📅 **Release Year:** `{document.get('release_year', 'N/A')}`\n"
        text += f"> ⭐ **Rating:** `{document.get('rating', 'N/A')}`\n"
        text += f"> 🔄 **Updated On:** `{document.get('updated_on', 'N/A')}`\n"
        text += f"> 🎭 **Genres:** `{', '.join(document.get('genres', []) or ['N/A'])}`\n"
        text += f"> 🌐 **Languages:** `{', '.join(document.get('languages', []) or ['N/A'])}`\n"
        text += f"> 🏷️ **Rip:** `{document.get('rip', 'N/A')}`\n"
        if media_type.lower() == "series":
            text += f"> 📺 **Status:** `{document.get('status', 'N/A')}`\n"
            text += f"> 📊 **Total Seasons:** `{document.get('total_seasons', 'N/A')}`\n"
            text += f"> 🎬 **Total Episodes:** `{document.get('total_episodes', 'N/A')}`\n"
        else:
            text += f"> ⏱️ **Runtime:** `{document.get('runtime', 'N/A')} minutes`\n"
        text += "\n**> ℹ️ Click on buttons below to edit fields"
    elif current_path == "seasons":
        text += "**> **📚 Seasons List**\n\n"
        for season in sorted(document.get("seasons", []), key=lambda x: x["season_number"]):
            text += f"**> 📺 Season {season.get('season_number')} - {len(season.get('episodes', []))} episodes\n"
    elif current_path.startswith("season_"):
        season_num = int(current_path.split("_")[1])
        season = next((s for s in document.get("seasons", []) if s.get("season_number") == season_num), None)
        if season:
            text += f"**> **Season {season_num}**\n\n"
            text += f"**> 📺 **Total Episodes:** `{len(season.get('episodes', []))}`\n\n"
            for ep in sorted(season.get("episodes", []), key=lambda x: x["episode_number"]):
                text += f"**> 🎬 **Episode {ep['episode_number']}:** `{ep.get('title', 'N/A')}`\n"
                if ep.get("telegram"):
                    text += f"**>    - Qualities: {', '.join([q['quality'] for q in ep['telegram']])}\n"
    elif current_path.startswith("edit_episode_"):
        parts = current_path.split("_")
        season_num = int(parts[2])
        episode_num = int(parts[3])
        season = next((s for s in document.get("seasons", []) if s.get("season_number") == season_num), None)
        if season:
            episode = next((e for e in season.get("episodes", []) if e.get("episode_number") == episode_num), None)
            if episode:
                text += f"**Editing Episode {episode_num} (Season {season_num})**\n\n"
                text += f"📌 **Title:** `{episode.get('title', 'N/A')}`\n"
                text += "\nPlease reply to this message with the new title."
    return text

async def start_edit_countdown(bot: Client, chat_id: int, msg_id: int):
    total_time = 60
    remaining = total_time
    data = user_data.get(msg_id)
    if not data or not data.get("waiting_for_input"):
        return
    original_prompt = data.get("editing_prompt", "")
    while remaining > 0 and data.get("waiting_for_input", False):
        new_text = f"{original_prompt}\n\n**> ⏳ Time remaining: {remaining} seconds"
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=msg_id,
                text=new_text,
                disable_web_page_preview=True,
                reply_markup=data.get("editing_keyboard")
            )
        except Exception as e:
            LOGGER.error(f"Countdown update failed: {e}")
        await asyncio.sleep(10)
        remaining -= 10
    if data.get("waiting_for_input", False):
        data["waiting_for_input"] = False
        data.pop("editing_field", None)
        data.pop("editing_path", None)
        if "episode_edit" in data:
            data.pop("episode_edit", None)
        text = format_document_for_display(data["document"], data["media_type"], data.get("current_path", "root"))
        keyboard = create_view_keyboard(
            data["media_type"],
            data["tmdb_id"],
            data["db_index"],
            data.get("current_path", "root"),
            data["document"]
        )
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=msg_id,
                text=text,
                disable_web_page_preview=True,
                reply_markup=keyboard
            )
        except Exception as e:
            LOGGER.error(f"Timeout update failed: {e}")

@Client.on_message(filters.command("edit") & filters.private & CustomFilters.owner)
async def edit_command(bot: Client, message: Message):
    parts = message.text.split()
    if len(parts) != 2:
        return await message.reply_text("Use this format: /edit https://domain/Series/3123/1", disable_web_page_preview=True)
    url = parts[1]
    parsed = urlparse(url)
    path = parsed.path.strip("/").split("/")
    if len(path) < 3 or not path[-2].isdigit() or not path[-1].isdigit():
        return await message.reply_text("The URL format is incorrect.", disable_web_page_preview=True)
    media_type, tmdb_id, db_index = path[-3].lower(), path[-2], path[-1]
    if media_type not in ("series", "movie"):
        return await message.reply_text("**> Media type must be 'Series' or 'Movie'.**", disable_web_page_preview=True)
    document = await db.get_document(media_type, tmdb_id, db_index)
    if not document:
        return await message.reply_text("**> Document not found in database.**", disable_web_page_preview=True)
    text = format_document_for_display(document, media_type)
    keyboard = create_view_keyboard(media_type, tmdb_id, db_index, "root", document)
    msg = await message.reply_text(text, reply_markup=keyboard, disable_web_page_preview=True)
    user_data[msg.id] = {
        "media_type": media_type,
        "tmdb_id": tmdb_id,
        "db_index": db_index,
        "document": document,
        "current_path": "root",
        "original_message": message.id,
        "waiting_for_input": False
    }

@Client.on_callback_query(filters.regex(r"^view_"))
async def view_callback(bot: Client, callback_query: CallbackQuery):
    msg_id = callback_query.message.id
    if msg_id not in user_data:
        return await callback_query.answer("Session expired. Please use /edit again.", show_alert=True)
    data = user_data[msg_id]
    data["current_path"] = callback_query.data.replace("view_", "")
    text = format_document_for_display(data["document"], data["media_type"], data["current_path"])
    keyboard = create_view_keyboard(
        data["media_type"],
        data["tmdb_id"],
        data["db_index"],
        data["current_path"],
        data["document"]
    )
    await callback_query.message.edit_text(text, disable_web_page_preview=True, reply_markup=keyboard)
    await callback_query.answer()

@Client.on_callback_query(filters.regex(r"^edit_"))
async def edit_field_callback(bot: Client, callback_query: CallbackQuery):
    msg_id = callback_query.message.id
    if msg_id not in user_data:
        return await callback_query.answer("Session expired. Please use /edit again.", show_alert=True)
    data = user_data[msg_id]
    parts = callback_query.data.split("_")
    if parts[1] == "episode" and parts[2] == "title":
        field = "episode_title"
        season_num = int(parts[3])
        episode_num = int(parts[4])
        season = next((s for s in data["document"].get("seasons", []) if s["season_number"] == season_num), None)
        if season:
            episode = next((e for e in season.get("episodes", []) if e["episode_number"] == episode_num), None)
            if episode:
                value = episode.get("title", "")
                prompt = (f"**✏️ Editing Episode {episode_num} (Season {season_num}) Title**\n\n"
                          f"Current title: `{value}`\n\n"
                          f"**> Please reply to this message with the new title:")
                data["episode_edit"] = {"season_num": season_num, "episode_num": episode_num}
            else:
                return await callback_query.answer("Episode not found.", show_alert=True)
        else:
            return await callback_query.answer("Season not found.", show_alert=True)
    else:
        field = "_".join(parts[1:-1])
        current_path = parts[-1]
        value = data["document"].get(field, "")
        if isinstance(value, list):
            value = ", ".join(value)
        prompt = (f"**✏️ Editing {field.replace('_', ' ').capitalize()}**\n\n"
                  f"Current value: `{value}`\n\n"
                  f"**> Please reply to this message with the new value:")
    data["editing_field"] = field
    data["editing_path"] = callback_query.data  
    data["waiting_for_input"] = True
    data["editing_prompt"] = prompt
    keyboard_buttons = [[InlineKeyboardButton("❌ Cancel Editing", callback_data="cancel_edit_input")]]
    keyboard = InlineKeyboardMarkup(keyboard_buttons)
    data["editing_keyboard"] = keyboard
    await callback_query.message.edit_text(prompt, disable_web_page_preview=True, reply_markup=keyboard)
    await callback_query.answer()
    data["edit_timer"] = asyncio.create_task(start_edit_countdown(bot, callback_query.message.chat.id, msg_id))

@Client.on_callback_query(filters.regex(r"^(save_changes|cancel_edit|cancel_edit_input)$"))
async def handle_save_cancel(bot: Client, callback_query: CallbackQuery):
    msg_id = callback_query.message.id
    if msg_id not in user_data:
        return await callback_query.answer("Session expired.", show_alert=True)
    data = user_data[msg_id]
    action = callback_query.data
    if action == "save_changes":
        try:
            await db.update_document(data["media_type"], data["tmdb_id"], data["db_index"], data["document"])
            await callback_query.message.edit_text("✅ Changes saved successfully.", disable_web_page_preview=True)
            await callback_query.answer("Saved!")
            if msg_id in user_data:
                del user_data[msg_id]
        except Exception as e:
            await callback_query.message.edit_text(f"❌ Error saving changes: {str(e)}", disable_web_page_preview=True)
            await callback_query.answer("Error!")
    elif action == "cancel_edit":
        await callback_query.message.edit_text("❌ Edit canceled.", disable_web_page_preview=True)
        await callback_query.answer("Canceled.")
        if data.get("edit_timer"):
            data["edit_timer"].cancel()
        if msg_id in user_data:
            del user_data[msg_id]
    elif action == "cancel_edit_input":
        data["waiting_for_input"] = False
        data.pop("editing_field", None)
        data.pop("editing_path", None)
        if "episode_edit" in data:
            data.pop("episode_edit", None)
        if data.get("edit_timer"):
            data["edit_timer"].cancel()
        text = format_document_for_display(data["document"], data["media_type"], data.get("current_path", "root"))
        keyboard = create_view_keyboard(
            data["media_type"],
            data["tmdb_id"],
            data["db_index"],
            data.get("current_path", "root"),
            data["document"]
        )
        await callback_query.message.edit_text(text, disable_web_page_preview=True, reply_markup=keyboard)
        await callback_query.answer("Editing canceled; returning to view.")

@Client.on_message(filters.private & CustomFilters.owner)
async def handle_edit_input(bot: Client, message: Message):
    if not message.reply_to_message:
        return
    msg_id = message.reply_to_message.id
    if msg_id not in user_data or not user_data[msg_id].get("waiting_for_input"):
        return
    data = user_data[msg_id]
    field = data["editing_field"]
    current_path = data["editing_path"]
    new_value = message.text.strip()
    if data.get("edit_timer"):
        data["edit_timer"].cancel()
        data.pop("edit_timer", None)
    validated, error = validate_input(field, new_value, data["media_type"])
    if error:
        await message.reply_text(f"❌ Invalid value: {error}\nPlease try again.", disable_web_page_preview=True, quote=True)
        return
    if field == "season_title":
        parts = current_path.split("_")
        season_num = int(parts[1])
        for season in data["document"].get("seasons", []):
            if season["season_number"] == season_num:
                season["title"] = validated
                break
    elif field == "episode_title":
        episode_edit = data.get("episode_edit")
        if not episode_edit:
            return await message.reply_text("Session error: Episode info missing.", disable_web_page_preview=True)
        season_num = episode_edit["season_num"]
        episode_num = episode_edit["episode_num"]
        for season in data["document"].get("seasons", []):
            if season["season_number"] == season_num:
                for episode in season.get("episodes", []):
                    if episode["episode_number"] == episode_num:
                        episode["title"] = validated
                        break
                break
        data["current_path"] = f"season_{season_num}"
    else:
        if field in ["genres", "languages"]:
            data["document"][field] = validated
        elif field in ["runtime", "total_seasons", "total_episodes", "release_year"]:
            data["document"][field] = validated
        elif field == "rating":
            data["document"][field] = validated
        elif field in ["poster", "backdrop"]:
            data["document"][field] = validated
        else:
            data["document"][field] = validated
    text = format_document_for_display(data["document"], data["media_type"], data.get("current_path", "root"))
    keyboard = create_view_keyboard(
        data["media_type"],
        data["tmdb_id"],
        data["db_index"],
        data.get("current_path", "root"),
        data["document"]
    )
    await bot.edit_message_text(
        chat_id=message.chat.id,
        message_id=msg_id,
        text=text,
        disable_web_page_preview=True,
        reply_markup=keyboard
    )
    data["waiting_for_input"] = False
    data.pop("editing_field", None)
    data.pop("editing_path", None)
    if "episode_edit" in data:
        data.pop("episode_edit", None)
    await message.delete()

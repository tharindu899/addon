## Easily Deploy to Heroku

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1s86kjrlOsdTos0M0BStvKmUiOovHoVjK)

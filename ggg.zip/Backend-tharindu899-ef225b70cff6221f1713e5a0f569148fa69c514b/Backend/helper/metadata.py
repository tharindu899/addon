import logging
import PTN
# from Backend.config import config_manager
from Backend.config_manager import config_manager

from Backend.helper.imdb import get_detail, get_season, search_title
from Backend.helper.mediainfo import get_media_quality
from themoviedb import aioTMDb
from Backend.helper.pyro import extract_tmdb_id, normalize_languages

tmdb = aioTMDb(key=config_manager.TMDB_API, language="en-US", region="US")

async def metadata(filename: str, media) -> dict:
    parsed = PTN.parse(filename)
    title = parsed.get('title')
    season = parsed.get('season')
    episode = parsed.get('episode')
    year = parsed.get('year')
    quality = parsed.get('resolution') or await get_media_quality(media)
    languages = normalize_languages(parsed.get('language'))
    rip = parsed.get('quality')
    
    # Determine the default ID from the config or filename.
    default_id = extract_tmdb_id(config_manager.USE_DEFAULT_ID) if config_manager.USE_DEFAULT_ID else extract_tmdb_id(filename)
    
    if title:
        if season and episode:
            return await fetch_tv_metadata(title, season, episode, default_id, quality, languages, rip)
        else:
            return await fetch_movie_metadata(title, year, quality, default_id, languages, rip)
    return None

async def fetch_tv_metadata(title: str, season: int, episode: int, default_id: str,
                            quality: str, languages: list, rip: str) -> dict:
    try:
        # If there is no valid default TMDB/IMDb id, search by title.
        if not default_id:
            if config_manager.USE_TMDB:
                tv_results = await tmdb.search().tv(query=title)
                tv_id = tv_results[0].id
                tv_details = await tmdb.tv(tv_id).details()
                try:
                    ep_details = await tmdb.episode(tv_id, season, episode).details()
                    ep_title = ep_details.name or f"S{season}E{episode}"
                    ep_backdrop = f"https://image.tmdb.org/t/p/original{ep_details.still_path}" if ep_details.still_path else ''
                except Exception:
                    ep_title, ep_backdrop = f"S{season}E{episode}", ''
            else:
                tv_result = await search_title(query=title, type="tvSeries")
                tv_id = tv_result['id']
                tv_details = await get_detail(imdb_id=tv_id)
                try:
                    ep_details = await get_season(imdb_id=tv_id, season_id=season, episode_id=episode)
                    if ep_details:
                        ep_title = ep_details.get('title', f"S{season}E{episode}")
                        ep_backdrop = ep_details.get('image', '')
                    else:
                        ep_title, ep_backdrop = f"S{season}E{episode}", ''
                except Exception:
                    ep_title, ep_backdrop = f"S{season}E{episode}", ''
        else:
            # default_id is provided.
            if default_id.startswith("tt"):
                tv_details = await get_detail(imdb_id=default_id)
                try:
                    ep_details = await get_season(imdb_id=default_id, season_id=season, episode_id=episode)
                    ep_title = ep_details.get('title', f"S{season}E{episode}")
                    ep_backdrop = ep_details.get('image', '')
                except Exception:
                    ep_title, ep_backdrop = f"S{season}E{episode}", ''
            else:
                tv_details = await tmdb.tv(int(default_id)).details()
                try:
                    ep_details = await tmdb.episode(int(default_id), season, episode).details()
                    ep_title = ep_details.name
                    ep_backdrop = f"https://image.tmdb.org/t/p/original{ep_details.still_path}" if ep_details.still_path else ''
                except Exception:
                    ep_title, ep_backdrop = f"S{season}E{episode}", ''
        
        # Extract metadata based on whether TMDB is used.
        if config_manager.USE_TMDB:
            tmdb_id = tv_details.id
            show_title = tv_details.name
            show_year = tv_details.first_air_date.year
            rate = tv_details.vote_average or 0
            description = tv_details.overview
            total_seasons = tv_details.number_of_seasons
            total_episodes = tv_details.number_of_episodes
            poster = f"https://image.tmdb.org/t/p/w500{tv_details.poster_path}" if tv_details.poster_path else ''
            backdrop = f"https://image.tmdb.org/t/p/original{tv_details.backdrop_path}" if tv_details.backdrop_path else ''
            status = tv_details.status
            genres = [genre.name for genre in tv_details.genres]
        else:
            tmdb_id = tv_details['id'].replace("tt", "")
            show_title = tv_details['title']
            show_year = tv_details['releaseDetailed']['year']
            rate = tv_details['rating']['star'] or 0
            description = tv_details['plot']
            total_seasons = len(tv_details.get('all_seasons', []))
            total_episodes = sum(len(season.get('episodes', [])) for season in tv_details.get('seasons', []))
            poster = tv_details.get('image', '')
            # Force re-search for additional details.
            tv_results = await tmdb.search().tv(query=show_title)
            tv_force_id = tv_results[0].id
            tv_force_details = await tmdb.tv(tv_force_id).details()
            backdrop = f"https://image.tmdb.org/t/p/original{tv_force_details.backdrop_path}" if tv_force_details.backdrop_path else ''
            status = tv_force_details.status
            genres = tv_details.get('genre', [])
        
        return {
            "tmdb_id": tmdb_id,
            "title": show_title,
            "year": show_year,
            "rate": rate,
            "description": description,
            "total_seasons": total_seasons,
            "total_episodes": total_episodes,
            "poster": poster,
            "backdrop": backdrop,
            "status": status,
            "genres": genres,
            "media_type": "tv",
            "season_number": season,
            "episode_number": episode,
            "episode_title": ep_title,
            "episode_backdrop": ep_backdrop,
            "quality": quality,
            "languages": languages or ['hi'],
            "rip": rip or 'Blu-ray'
        }
    except Exception as e:
        logging.error(f"Error fetching TV show details: {e}")
        return None

async def fetch_movie_metadata(title: str, year=None, quality=None, default_id=None,
                               languages=None, rip=None) -> dict:
    try:
        if not default_id:
            if config_manager.USE_TMDB:
                movies = await tmdb.search().movies(query=title, year=year)
                movie_id = movies[0].id
                movie_details = await tmdb.movie(int(movie_id)).details()
            else:
                movie_result = await search_title(query=title, type="movie")
                movie_id = movie_result['id']
                movie_details = await get_detail(imdb_id=movie_id)
        else:
            if default_id.startswith("tt"):
                movie_details = await get_detail(imdb_id=default_id)
            else:
                movie_details = await tmdb.movie(int(default_id)).details()
        
        if config_manager.USE_TMDB:
            tmdb_id = movie_details.id
            movie_title = movie_details.title
            movie_year = movie_details.release_date.year
            rate = movie_details.vote_average or 0
            description = movie_details.overview
            poster = f"https://image.tmdb.org/t/p/w500{movie_details.poster_path}" if movie_details.poster_path else ''
            backdrop = f"https://image.tmdb.org/t/p/original{movie_details.backdrop_path}" if movie_details.backdrop_path else None
            if not backdrop:
                movies = await tmdb.search().movies(query=movie_title, year=movie_year)
                movie_force_id = movies[0].id
                movie_details_force = await tmdb.movie(movie_force_id).details()
                backdrop = f"https://image.tmdb.org/t/p/original{movie_details_force.backdrop_path}" if movie_details_force.backdrop_path else ''
            runtime = movie_details.runtime
            genres = [genre.name for genre in movie_details.genres]
        else:
            tmdb_id = movie_details['id'].replace("tt", "")
            movie_title = movie_details['title']
            movie_year = movie_details['releaseDetailed']['year']
            rate = movie_details['rating']['star'] or 0
            description = movie_details['plot']
            poster = movie_details.get('image', '')
            backdrop = movie_details.get('backdrop', '')
            runtime = movie_details['runtimeSeconds'] // 60
            genres = movie_details['genre']
        
        return {
            "tmdb_id": tmdb_id,
            "title": movie_title,
            "year": movie_year,
            "rate": rate,
            "description": description,
            "poster": poster,
            "backdrop": backdrop or '',
            "media_type": "movie",
            "genres": genres,
            "runtime": runtime,
            "quality": quality,
            "languages": languages or ['hi'],
            "rip": rip or 'Blu-ray'
        }
    except Exception as e:
        logging.error(f"Error fetching movie details: {e}")
        return None
                                
